import React, { useRef, useState, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

interface FaceCaptureProps {
  onCapture?: (success: boolean) => void;
  mode: 'register' | 'verify';
}

export function FaceCapture({ onCapture, mode }: FaceCaptureProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [streaming, setStreaming] = useState(false);
  const [loading, setLoading] = useState(false);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setStreaming(true);
      }
    } catch (error) {
      toast.error('Unable to access camera');
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
      tracks.forEach(track => track.stop());
      setStreaming(false);
    }
  };

  const captureImage = useCallback(async () => {
    if (!videoRef.current || !streaming || loading) return;

    try {
      setLoading(true);
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      ctx.drawImage(videoRef.current, 0, 0);
      const imageData = canvas.toDataURL('image/jpeg');

      const user = await supabase.auth.getUser();
      if (!user.data.user) throw new Error('User not authenticated');

      const endpoint = mode === 'register' 
        ? '/api/register-face'
        : '/api/verify-face';

      const response = await fetch(`http://localhost:5000${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.data.user.id,
          image: imageData,
        }),
      });

      const result = await response.json();

      if (response.ok) {
        if (mode === 'register') {
          toast.success('Face registered successfully');
        } else if (result.verified) {
          toast.success('Face verified successfully');
        } else {
          toast.error('Face verification failed');
        }
        onCapture?.(true);
      } else {
        throw new Error(result.error);
      }
    } catch (error: any) {
      toast.error(error.message);
      onCapture?.(false);
    } finally {
      setLoading(false);
      stopCamera();
    }
  }, [streaming, loading, mode, onCapture]);

  React.useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="flex flex-col items-center space-y-4">
      <div className="relative w-[640px] h-[480px] bg-gray-100 rounded-lg overflow-hidden">
        <video
          ref={videoRef}
          className="w-full h-full object-cover"
          autoPlay
          playsInline
          onCanPlay={() => {
            if (videoRef.current) {
              videoRef.current.play();
            }
          }}
        />
      </div>
      <div className="flex space-x-4">
        {!streaming ? (
          <button
            onClick={startCamera}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          >
            Start Camera
          </button>
        ) : (
          <button
            onClick={captureImage}
            disabled={loading}
            className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 disabled:bg-gray-400"
          >
            {loading ? 'Processing...' : mode === 'register' ? 'Register Face' : 'Verify Face'}
          </button>
        )}
      </div>
    </div>
  );
}