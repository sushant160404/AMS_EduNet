import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { format } from 'date-fns';
import toast from 'react-hot-toast';
import { FaceCapture } from './FaceCapture';

export function AttendanceMarker() {
  const [loading, setLoading] = useState(false);
  const [todayAttendance, setTodayAttendance] = useState<any>(null);
  const [showFaceVerification, setShowFaceVerification] = useState(false);

  useEffect(() => {
    checkTodayAttendance();
  }, []);

  const checkTodayAttendance = async () => {
    try {
      const user = supabase.auth.getUser();
      if (!user) return;

      const today = new Date().toISOString().split('T')[0];
      const { data, error } = await supabase
        .from('attendance')
        .select('*')
        .eq('user_id', (await user).data.user?.id)
        .eq('date', today)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      setTodayAttendance(data);
    } catch (error: any) {
      toast.error(error.message);
    }
  };

  const markAttendance = async () => {
    setShowFaceVerification(true);
  };

  const handleFaceVerification = async (success: boolean) => {
    if (success) {
      try {
        setLoading(true);
        const user = supabase.auth.getUser();
        if (!user) return;

        const { error } = await supabase.from('attendance').insert([
          {
            user_id: (await user).data.user?.id,
            date: new Date().toISOString().split('T')[0],
            time: new Date().toISOString(),
          },
        ]);

        if (error) throw error;
        toast.success('Attendance marked successfully!');
        checkTodayAttendance();
      } catch (error: any) {
        toast.error(error.message);
      } finally {
        setLoading(false);
      }
    }
    setShowFaceVerification(false);
  };

  return (
    <div className="max-w-4xl mx-auto mt-10 bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-4">Mark Attendance</h2>
      <div className="mb-4">
        <p className="text-gray-600">
          Today: {format(new Date(), 'MMMM d, yyyy')}
        </p>
      </div>
      {showFaceVerification ? (
        <FaceCapture mode="verify" onCapture={handleFaceVerification} />
      ) : todayAttendance ? (
        <div className="bg-green-50 p-4 rounded-md">
          <p className="text-green-800">
            Attendance already marked at{' '}
            {format(new Date(todayAttendance.time), 'h:mm a')}
          </p>
        </div>
      ) : (
        <button
          onClick={markAttendance}
          disabled={loading}
          className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          {loading ? 'Processing...' : 'Mark Attendance'}
        </button>
      )}
    </div>
  );
}