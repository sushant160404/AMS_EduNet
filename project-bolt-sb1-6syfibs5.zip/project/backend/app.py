from flask import Flask, request, jsonify
from flask_cors import CORS
import face_recognition
import numpy as np
import cv2
import os
import base64
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Directory to store known faces
KNOWN_FACES_DIR = "known_faces"
if not os.path.exists(KNOWN_FACES_DIR):
    os.makedirs(KNOWN_FACES_DIR)

def base64_to_image(base64_string):
    # Remove data:image/jpeg;base64, from the string if present
    if 'base64,' in base64_string:
        base64_string = base64_string.split('base64,')[1]
    img_data = base64.b64decode(base64_string)
    nparr = np.frombuffer(img_data, np.uint8)
    return cv2.imdecode(nparr, cv2.IMREAD_COLOR)

@app.route('/api/register-face', methods=['POST'])
def register_face():
    try:
        data = request.json
        user_id = data['userId']
        image_data = data['image']
        
        # Convert base64 image to CV2 format
        img = base64_to_image(image_data)
        
        # Detect faces in the image
        face_locations = face_recognition.face_locations(img)
        if not face_locations:
            return jsonify({'error': 'No face detected'}), 400
        
        # Get face encodings
        face_encoding = face_recognition.face_encodings(img, face_locations)[0]
        
        # Save face encoding
        np.save(os.path.join(KNOWN_FACES_DIR, f"{user_id}.npy"), face_encoding)
        
        return jsonify({'message': 'Face registered successfully'})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/verify-face', methods=['POST'])
def verify_face():
    try:
        data = request.json
        user_id = data['userId']
        image_data = data['image']
        
        # Load known face encoding
        known_face_path = os.path.join(KNOWN_FACES_DIR, f"{user_id}.npy")
        if not os.path.exists(known_face_path):
            return jsonify({'error': 'Face not registered'}), 400
        
        known_face_encoding = np.load(known_face_path)
        
        # Convert base64 image to CV2 format
        img = base64_to_image(image_data)
        
        # Detect faces in the image
        face_locations = face_recognition.face_locations(img)
        if not face_locations:
            return jsonify({'error': 'No face detected'}), 400
        
        # Get face encodings
        face_encoding = face_recognition.face_encodings(img, face_locations)[0]
        
        # Compare faces
        matches = face_recognition.compare_faces([known_face_encoding], face_encoding)
        
        if matches[0]:
            return jsonify({'verified': True})
        else:
            return jsonify({'verified': False})
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)